<template>
<div class="app">
  <transition name="header">
  <header v-show="show">Apresentando o H1</header>
  </transition>
  <button @click="show=!show">Alterar estado</button>
</div>
  
</template>

<script>


export default {
  name: 'App',
    data(){
      return{
        show: false
      }
    }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}


/* Primeiro quadro de estilo */
.header-leave-to,
.header-enter-from{ 
  background-color: black;
  /* background-color: white; */
  opacity: 0;
  font-size: 0px;
}

.header-leave-from,
.header-enter-to{
  /* background-color: rgb(185, 0, 0); */
  opacity: 1;
  font-size: 1em;
}

.header-leave-active,
.header-enter-active{
  transition: all 2s;
}
</style>
