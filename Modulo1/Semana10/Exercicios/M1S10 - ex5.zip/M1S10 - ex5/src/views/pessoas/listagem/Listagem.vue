<template>
  <div class="listagem">
      <h1>Listagem</h1>
      
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>