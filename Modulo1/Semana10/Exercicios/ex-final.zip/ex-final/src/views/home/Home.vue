<template>
  <div id="home">
      <h1>Home</h1>
      <router-view></router-view>
  </div>
  
</template>

<script>


export default {
  data(){
      return{

      }
  },
  methods:{

  }
}
</script>

<style>
#app {
  
}
</style>