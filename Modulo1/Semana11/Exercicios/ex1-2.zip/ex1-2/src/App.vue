<template>
  <div id="app">
    <NavBar/>

    <router-view></router-view>
    <hr>
    <div class="consultaPess">
      <div class="pesquisaPessoa">
        <label for="">Id:</label>
        <input type="number" v-model="id">
        <button @click="buscaPessoa">GET/ID</button>
        div.
      </div>
      <div class="listagem">
        <button @click="buscaPessoas">GET</button>
        <div>{{cadastros}}</div>
      </div>
    </div>
  </div>

</template>


<script>

import NavBar from './components/shared/navbar/NavBar.vue'
import axios from 'axios'

export default {
  components:{
    NavBar
  },
  data(){
    return{
      id: 0,
      cadastro: {},
      cadastros: [],
    }
  },

  methods:{
   async buscaPessoa(){
      const promise = axios.get(`https://627bb940b54fe6ee008db865.mockapi.io/pessoas/pessoa/${this.id}`)
      await promise.then((response) => {
        this.cadastro = response.data;
      }).catch((error) => {
        alert(error)
      })
    },

    async buscaPessoas(){
      const promise = axios.get('https://627bb940b54fe6ee008db865.mockapi.io/pessoas/pessoa')       
      // name: 'teste',
        // email:'teste2'
       await promise.then((response) => {
          this.cadastros = response.data;
        }).catch((error) => {
          alert(error)
        })
    },

  }

}
</script>

<style>

</style>