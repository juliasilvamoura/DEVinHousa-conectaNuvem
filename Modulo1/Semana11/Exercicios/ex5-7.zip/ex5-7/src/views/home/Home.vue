<template>
  <div id="home">
      <h1>Home</h1>
      <router-link to="/pessoas/cadastro">Cadastro</router-link>
  </div>
  
</template>

<script>


export default {
  data(){
      return{

      }
  },
  methods:{

  }
}
</script>

<style>
#app {
  
}
</style>