<template>
  <h1>Boas Vindas</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>