var nome = window.prompt("Digite seu nome: ");
var sobrenome = window.prompt("Digite seu sobrenome: ");

alert(`nome completo: ${nome} ${sobrenome}`)

function enviar(){
    //alert("Dados Enviados com Sucesso!")
    confirm("Enviar formulário?")

}