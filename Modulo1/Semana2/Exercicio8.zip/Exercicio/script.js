var nome = window.prompt("Digite seu nome:");
alert(`nome: ${nome}`)

function enviar(){
    //alert("Dados Enviados com Sucesso!")
    confirm("Enviar formulário?")

}