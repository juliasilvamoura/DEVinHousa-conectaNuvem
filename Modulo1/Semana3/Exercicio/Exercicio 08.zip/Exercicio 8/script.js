const bntAdicionar = document.querySelector('.adicionar')
const listaProduto = document.querySelector('.listaProduto')
const bntSalvar = document.querySelector('.salvar')
const bntCarregarLista = document.querySelector('.carregarlista')

bntAdicionar.addEventListener('click', salvarCompra)
bntSalvar.addEventListener('click', converterJSON)
bntCarregarLista.addEventListener('click', carregarLista)



function salvarCompra(){
    const produtos = document.querySelector('.produtos').value
    if(produtos == ''){
        alert("Error!")
        console.log(produtos)
    } else{
    const li = document.createElement('li')
    const h3 = document.createElement('h3')
    const img = document.createElement('img')

    h3.innerHTML = produtos
    img.src='https://cdn-icons-png.flaticon.com/512/39/39220.png'
    img.alt='Icone lixeira'
    img.addEventListener('click', removerProduto)

    li.appendChild(h3)
    li.appendChild(img)

    listaProduto.appendChild(li)

    
    }
       
}

function removerProduto(e){
    const produtoClicado = e.target.parentNode;

    produtoClicado.remove()
}


function converterJSON(){
    var textJSON = JSON.stringify(listaProduto) // ele está carregando null
    console.log(textJSON)
    console.log(lista.value)

    // localStorage.setItem('ListaDeCompras', JSON.stringify());
}

function carregarLista(){
    //JSON.parse(localStorage.getItem('ListaDeCompras'));
}