
var nome = prompt("Digite sei nome")
var idade = prompt("Digite sua idade")
var esport = confirm("Quer praticar um esporte")

if(esport === true)
    alert(`${nome}, de ${idade} anos, quer praticar esportes`)
else 
    alert(`${nome}, de ${idade} anos, não quer praticar esportes`)
