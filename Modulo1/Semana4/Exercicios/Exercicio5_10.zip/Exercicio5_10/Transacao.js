class Transacao{
    constructor(conta, saldoConta){
        this.conta = conta;
        this.saldoConta = saldoConta;
    }


    transferir(valor){

        if(valor <= this.saldoConta){
            this.saldoConta -= valor;
            console.log(`Pix ${valor} realizado, saldo ${this.saldoConta}`)
        }else console.log("Saldo Insuficiete")
        
        
    }

    depositar(valor){
        this.saldoConta += valor;
        console.log(`Depósito PIX ${valor} realizado, saldo ${this.saldoConta}`)
    }

    imprimirExtrato(){
        console.log(`Saldo da Conta R$ ${this.saldoConta}`)
    }
}

const aux = new Transacao(14215,500);
aux.depositar(100)
aux.transferir(50)
aux.imprimirExtrato()