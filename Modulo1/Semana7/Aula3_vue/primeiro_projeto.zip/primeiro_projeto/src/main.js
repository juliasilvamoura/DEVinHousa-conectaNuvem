import { createApp } from 'vue'
import App from './App.vue'

createApp(App).mount('#app')

// A configuração é feita toda aqui, inclusive do backend com o front
