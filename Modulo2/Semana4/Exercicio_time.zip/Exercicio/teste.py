from os.path import dirname, abspath, join
import json

root_path = dirname(abspath(__file__))
dados_path = join(root_path, "data")
data = join(dados_path, "medico.json")

