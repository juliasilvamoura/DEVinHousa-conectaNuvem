// For Firebase JS SDK v7.20.0 and later, measurementId is optional
var config = {
    apiKey: "AIzaSyCHunH5CuYwS8O3sajBb7iOyQiNeR_VHAE",
    authDomain: "sample-devinhouse-fa057.firebaseapp.com",
    databaseURL: "https://sample-devinhouse-fa057-default-rtdb.firebaseio.com",
    projectId: "sample-devinhouse-fa057",
    storageBucket: "sample-devinhouse-fa057.appspot.com",
    messagingSenderId: "606799964935",
    appId: "1:606799964935:web:3d96224e1b7885fb52f3a2",
    measurementId: "G-2962RP6PF8"
  };
  firebase.initializeApp(config);