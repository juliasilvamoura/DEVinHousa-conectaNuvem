<template>
  <div class="bg">Espaço para implementar o componente do Exercício 5</div>
</template>

<script>
export default {
  name: "ExercicioCinco",
  data() {
    return {};
  },
  methods: {},
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.bg {
  background-color: #eee;
  padding: 64px 32px;
}
</style>
