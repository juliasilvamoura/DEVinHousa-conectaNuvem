<template>
  <div class="about">
    <h1>Sobre</h1>

    <p>
      Este é o projeto base a ser utilizado para a realização dos exercícios
      semanais referentes à disciplina <strong>Testes Unitários com Vue</strong>
    </p>
  </div>
</template>
